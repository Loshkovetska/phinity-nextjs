declare module '*.svg'
