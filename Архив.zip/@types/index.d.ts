declare module 'fontfaceobserver'
