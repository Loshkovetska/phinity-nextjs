declare module '*.jpeg'
