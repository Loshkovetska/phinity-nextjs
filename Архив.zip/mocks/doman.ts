export const DOMAIN = 'https://phinitytherapy.com/admin/'
