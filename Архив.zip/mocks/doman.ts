export const DOMAIN = 'https://admin.phinitytherapy.com/'
