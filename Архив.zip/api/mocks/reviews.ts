export type Review = {
  title: string
  text: string
  sub: string
  rating: number
}

