import img from '../../assets/unsplash_HIB5kZNkVjo.png'
import img1 from '../../assets/unsplash_HIB5kZNkVjo (1).png'
import img2 from '../../assets/unsplash_HIB5kZNkVjo (2).png'
const images = [img, img1, img2, img, img1, img2, img, img1, img2]

export default images
