export type Service = {
  id: number
  title: string
  img: string
  link?: string
}
