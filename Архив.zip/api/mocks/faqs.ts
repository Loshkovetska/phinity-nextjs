export type Faq = {
  id: number
  title: string
  text: string
}
